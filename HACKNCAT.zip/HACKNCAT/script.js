var form = document.getElementById("ideaForm");

form.addEventListener("submit", function(e) {
    e.preventDefault();

    var title      = document.getElementById("title").value;
    var problem    = document.getElementById("problem").value;
    var solution   = document.getElementById("solution").value;
    var audience   = document.getElementById("audience").value;
    var howItWorks = document.getElementById("howItWorks").value;

    // check all fields are filled in
    if (title == "" || problem == "" || solution == "" || audience == "" || howItWorks == "") {
        alert("Please fill in all fields before submitting.");
        return;
    }

    var ideaData = {
        title:      title,
        problem:    problem,
        solution:   solution,
        audience:   audience,
        howItWorks: howItWorks
    };

    console.log("Idea submitted:", ideaData);

    document.getElementById("successMsg").style.display = "block";

    form.reset();

});